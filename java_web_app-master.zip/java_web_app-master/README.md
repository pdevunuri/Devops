# java_web_app
A simple Java WAR using Maven build
